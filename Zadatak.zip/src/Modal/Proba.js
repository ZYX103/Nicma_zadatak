import Modal from "./Modal";

const Proba = () => {
  return (
    <Modal>
      <div>
        {" "}
        <div>Bla</div>
        <input type="text" />
        <p>još malo teksta</p>
      </div>
    </Modal>
  );
};

export default Proba;
